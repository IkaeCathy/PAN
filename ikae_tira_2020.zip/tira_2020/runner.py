# -*- coding: utf-8 -*-

import os
import time


print ("runner.py started")

startTime = time.clock()

# Command used for the TIRA system
os.system("rm UniNEDoc.doc")
os.system("python UniNE.py -i \"inputFolder/\" -o \"outputFolder/\"")

print ("\n runner done in %.2fs" % (time.clock() - startTime))
