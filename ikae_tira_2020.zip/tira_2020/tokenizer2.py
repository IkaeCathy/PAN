import unicodedata
import sys
if sys.version_info[0] >= 3:
          unicode = str
#
# Code  L = letter
#       Cc = control char (e.g.. newline)
#       Cs = emoticons
#       Nd = numeric
#       P. = punctuation
#       Zs  = space
#       Sc  = symbol (e.g. $)
#       Sm  = symbol (e.g. <)
#      


def tokenizeLineUTF8(newLine):
   aListChar = []
   aListCode = []
   aListCode2 = []
   for i, c in enumerate(newLine):
      aListCode.append(unicodedata.category(c)[0])
      aListCode2.append(unicodedata.category(c)[1])
      aListChar.append(c)
   seqChar = seqPunct = seqNumber = seqEmoji = seqSymbol = False
   aLen = len(aListCode)
   aToken = u''
   aListOfWord = []
   for anIndex in range(aLen):
      aCode  = aListCode[anIndex]
      aCode2 = aListCode2[anIndex]
      aChar = aListChar[anIndex]
      if ((aCode == "L") & (seqChar)):
         aToken = aToken + aChar
      elif ((aCode == "P") & (seqPunct | seqNumber)):
         aToken = aToken + aChar
         seqPunct = True
         seqNumber = False
      elif ((aCode == "N") & (seqPunct | seqNumber | seqSymbol)):
         aToken = aToken + aChar
         seqNumber = True
         seqPunct = seqSymbol = False
      elif ((aCode == "S") & (seqPunct | seqNumber | seqSymbol)):
         aToken = aToken + aChar
         seqSymbol = True
         seqPunct = seqNumber = False
      elif (((aCode == "C") & (aCode2 == "s")) & seqEmoji):
         aToken = aToken + aChar
      elif ((aCode == "Z") | ((aCode == "C") & (aCode2 != "s")) | (aCode == "M")):
         if (len(aToken) > 0):
            aListOfWord.append(aToken)
         aToken = u''
         seqChar = seqPunct = seqNumber = seqEmoji = seqSymbol = False
      elif ((aCode == "L") & (not seqChar)):
         if (len(aToken) > 0):
            aListOfWord.append(aToken)
         aToken = aChar
         seqChar = True
         seqPunct = seqNumber = seqEmoji = seqSymbol = False
      elif ((aCode == "P") & (not seqPunct)):
         if (len(aToken) > 0):
            aListOfWord.append(aToken)
         aToken = aChar
         seqPunct = True
         seqChar = seqNumber = seqEmoji = seqSymbol = False
      elif ((aCode == "N") & (not seqNumber)):
         if (len(aToken) > 0):
            aListOfWord.append(aToken)
         aToken = aChar
         seqNumber = True
         seqChar = seqPunct = seqEmoji = seqSymbol = False
      elif ((aCode == "S") & (not seqSymbol)):
         if (len(aToken) > 0):
            aListOfWord.append(aToken)
         aToken = aChar
         seqSymbol = True
         seqChar = seqPunct = seqEmoji = seqNumber  = False
      elif (((aCode == "C") & (aCode2 == "s")) & (not seqEmoji)):
         if (len(aToken) > 0):
            aListOfWord.append(aToken)
         aToken = aChar
         seqEmoji = True
         seqChar = seqPunct = seqNumber = seqSymbol = False
   if (len(aToken) > 0):
      aListOfWord.append(aToken)
   return(aListOfWord)
