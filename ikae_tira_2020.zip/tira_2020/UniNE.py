# -*- coding: utf-8 -*-

import getopt
import os
import random
import re
import sys
import math, codecs, string, fnmatch, unicodedata

from  Gender_Attribution2020_1 import *


print ("UniNE.py loaded")

random.seed(1811)  # make results reproducible


if __name__ == '__main__':
    print ("UniNE.py started")

    inputFolder = ""
    outputFolder = ""

    try:
        opts, args = getopt.getopt(sys.argv[1:], "i:o:")
    except getopt.GetoptError:
        print ("UniNE.py -i <inFolder> -o <outFolder>")  # Tira command format
        sys.exit(2)
    for opt, arg in opts:
        if opt == "-i":
            inputFolder = arg
        elif opt == "-o":
            outputFolder = arg

    assert len(inputFolder) > 0      # if not true, stop the process
    print ("Input folder is", inputFolder)
    assert len(outputFolder) > 0
    print ("Output folder is", outputFolder)
#
#  Start here the real procedure
#
    author_profiling(inputFolder, outputFolder)
##    doTransformTestPAN2019(inputFolder, 'UniNEDoc.txt', '.xml')
##    print "Init done"
##    classification('UniNEDoc.txt', outputFolder, './Data/VocUniq.Bot.txt', './Data/VocUniq.Human.txt', './Data/VocUniq.Male.txt',
##                   './Data/VocUniq.Female.txt', './Data/VocBH9.txt', './Data/VocMF9.txt', './Data/Bot.Doc.txt',
##                   './Data/Human.Doc.txt', './Data/Male.Doc.txt', './Data/Female.Doc.txt')
    exit(0)
